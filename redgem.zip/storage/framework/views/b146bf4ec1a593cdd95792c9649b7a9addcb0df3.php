

<footer class="justify-around">
    <div class="container">
        <div class="sec aboutus">
            <h2>About Us</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum iste ipsum reiciendis dolor molestiae architecto, amet unde et repellendus iusto?</p>
            <ul class="sci text-white">
                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
        </div>
      
    <div class="sec quicklinks">
        <h2>Quick Links</h2>
        <ul>
            <li><a href="#">About</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Help</a></li>
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Contacts</a></li>
        </ul>
    </div>
    <div class="sec contact">
        <h2 id="contactus">Contact Info</h2>
        <ul class="info">
            <li>
            <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
            <span>643, Loma street Phonexvilla, ile-ife, <br>Nigeria</span></li>
            </li>
            <li>
            <span><i class="fa fa-phone" aria-hidden="true"></i></span>
            <p><a href="tel:2348149637835">+2348149637835</a><br>
                <a href="tel:2348149637835">+2348149637835</a></p>
        </li>
            <li>
            <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
            <p><a href="mailto:powerofelectron616@gmail.com"></a>
        </li>
        </ul>
    </div>
</div>
<div class="copyrighttext">
    <p>Copyright  2021 RedGEM Technologies Inc. All Rights Reserved.</p>
</div>
</footer><?php /**PATH C:\xampp\htdocs\Laravel\redgem\resources\views/layouts/footer.blade.php ENDPATH**/ ?>